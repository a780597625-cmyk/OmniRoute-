import React from 'react'
import ReactDOM from 'react-dom/client'
import MobileApp from './MobileApp'
import './mobile.css'

const rootElement = document.getElementById('root')

if (!rootElement) {
  throw new Error('لم يتم العثور على عنصر التطبيق root')
}

ReactDOM.createRoot(rootElement).render(
  <React.StrictMode>
    <MobileApp />
  </React.StrictMode>,
)
