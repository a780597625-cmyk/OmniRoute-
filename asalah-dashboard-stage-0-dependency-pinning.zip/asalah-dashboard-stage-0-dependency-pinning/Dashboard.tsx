import { useEffect, useMemo, useState } from 'react'
import type { FormEvent } from 'react'
import type { SupabaseClient } from '@supabase/supabase-js'
import './Dashboard.css'

type Customer = {
  id: string
  user_id: string
  name: string
  phone: string | null
  status: string
  next_follow_up: string | null
  next_follow_up_time: string | null
  follow_up_repeat: string | null
  source: string | null
  request: string | null
  address: string | null
  note: string | null
  lost_reason: string | null
  deleted_at: string | null
  created_at: string
  updated_at: string
}

type Order = {
  id: string
  user_id: string
  customer_id: string
  product: string
  total: number
  deposit: number
  status: string
  delivery_date: string | null
  delivery_time: string | null
  reminder_days: number
  source: string | null
  size: string | null
  fabric: string | null
  note: string | null
  attachment_path: string | null
  rating: number | null
  created_at: string
  updated_at: string
}

type OrderPayment = {
  id: string
  order_id: string
  amount: number
  paid_at: string
  note: string | null
}

type FollowUp = {
  id: string
  user_id: string
  customer_id: string
  followed_at: string
  result: string | null
  note: string | null
  next_follow_up: string | null
  next_follow_up_time: string | null
  status: string
}

type Complaint = {
  id: string
  user_id: string
  customer_id: string
  complaint: string
  status: string
  created_at: string
  resolved_at: string | null
  updated_at: string
}

type AutomationRule = {
  user_id: string
  rule_key: string
  enabled: boolean
  updated_at: string
}

type UserSettings = {
  user_id: string
  notifications_enabled: boolean
  contacts_sync_enabled: boolean
  morning_summary_enabled: boolean
  weekly_summary_enabled: boolean
  session_persistence_enabled: boolean
  dark_mode_enabled: boolean
  monthly_customer_goal: number
  updated_at: string
}

type Tab = 'dashboard' | 'customers' | 'orders' | 'followups' | 'settings'
type IconName = 'home' | 'users' | 'box' | 'clock' | 'settings'

type CustomerForm = {
  name: string
  phone: string
  status: string
  source: string
  request: string
  address: string
  note: string
  next_follow_up: string
  next_follow_up_time: string
  follow_up_repeat: string
  lost_reason: string
}

type OrderForm = {
  customer_id: string
  product: string
  total: string
  deposit: string
  status: string
  delivery_date: string
  delivery_time: string
  reminder_days: string
  source: string
  size: string
  fabric: string
  note: string
}

type FollowUpForm = {
  customer_id: string
  result: string
  note: string
  next_follow_up: string
  next_follow_up_time: string
  status: string
}

type ComplaintForm = {
  customer_id: string
  complaint: string
}

const orderStages = ['جديد', 'أخذ المقاسات', 'قيد التفصيل', 'قيد التجهيز', 'جاهز', 'تم التسليم']
const customerStatuses = ['مهتم', 'تفاوض', 'متابعة', 'اشترى', 'فقد']
const customerSources = ['فيسبوك', 'إنستغرام', 'واتساب', 'إحالة', 'زيارة', 'أخرى']

const ruleDefinitions = [
  {
    key: 'a',
    text: 'عميل «مهتم» بدون متابعة 7 أيام ← ينتقل إلى «متابعة» ويصلك تنبيه',
  },
  {
    key: 'b',
    text: 'طلبية تُسلَّم ← عميلها يتحول إلى «اشترى»',
  },
  {
    key: 'c',
    text: 'طلبية سُلّمت وبقي عليها مبلغ ← متابعة تحصيل اليوم',
  },
  {
    key: 'd',
    text: 'متابعة متأخرة أكثر من 3 أيام ← تُنقل إلى اليوم',
  },
  {
    key: 'e',
    text: 'استلام عربون على طلبية «جديد» ← تنتقل إلى «قيد التفصيل»',
  },
  {
    key: 'f',
    text: 'بعد يومين من التسليم ← متابعة «اطلب رأي العميل»',
  },
  {
    key: 'g',
    text: 'عميل «غير مهتم» ← إيقاف جميع متابعاته',
  },
  {
    key: 'h',
    text: 'عميل «اشترى» بدون متابعة ← متابعة ضمان وصيانة بعد 6 أشهر',
  },
] as const

const navItems: Array<{ id: Tab; label: string; icon: IconName }> = [
  { id: 'dashboard', label: 'الرئيسية', icon: 'home' },
  { id: 'customers', label: 'العملاء', icon: 'users' },
  { id: 'orders', label: 'الطلبيات', icon: 'box' },
  { id: 'followups', label: 'المتابعات', icon: 'clock' },
  { id: 'settings', label: 'الإعدادات', icon: 'settings' },
]

const emptyCustomerForm: CustomerForm = {
  name: '',
  phone: '',
  status: 'مهتم',
  source: '',
  request: '',
  address: '',
  note: '',
  next_follow_up: '',
  next_follow_up_time: '',
  follow_up_repeat: 'بدون تكرار',
  lost_reason: '',
}

const emptyOrderForm: OrderForm = {
  customer_id: '',
  product: '',
  total: '',
  deposit: '',
  status: 'جديد',
  delivery_date: '',
  delivery_time: '',
  reminder_days: '1',
  source: '',
  size: '',
  fabric: '',
  note: '',
}

const emptyFollowUpForm: FollowUpForm = {
  customer_id: '',
  result: '',
  note: '',
  next_follow_up: '',
  next_follow_up_time: '',
  status: 'مجدولة',
}

const emptyComplaintForm: ComplaintForm = {
  customer_id: '',
  complaint: '',
}

function todayLocal() {
  const date = new Date()
  const pad = (value: number) => String(value).padStart(2, '0')
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`
}

function formatTime(value: string | null) {
  return value ? value.slice(0, 5) : ''
}

function formatDate(value: string | null) {
  if (!value) return 'بدون موعد'
  const date = new Date(`${value}T00:00:00`)
  if (Number.isNaN(date.getTime())) return value
  return new Intl.DateTimeFormat('ar-YE', {
    day: 'numeric',
    month: 'short',
  }).format(date)
}

function formatMoney(value: number | string) {
  return `${new Intl.NumberFormat('ar-YE').format(Number(value) || 0)} ر.ي`
}

function normalizeYemeniPhone(value: string) {
  const digits = value.replace(/\D/g, '')
  if (digits.startsWith('00967')) return `+${digits.slice(2)}`
  if (digits.startsWith('967')) return `+${digits}`
  if (digits.startsWith('7') && digits.length === 9) return `+967${digits}`
  return value.trim()
}

function isValidYemeniPhone(value: string) {
  return /^\+9677\d{8}$/.test(normalizeYemeniPhone(value))
}

function dateDifferenceInDays(date: string) {
  const target = new Date(`${date}T00:00:00`)
  const today = new Date(`${todayLocal()}T00:00:00`)
  return Math.floor((today.getTime() - target.getTime()) / 86400000)
}

function addDays(days: number) {
  const date = new Date(`${todayLocal()}T00:00:00`)
  date.setDate(date.getDate() + days)
  const pad = (value: number) => String(value).padStart(2, '0')
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`
}

function Icon({ name }: { name: IconName }) {
  const common = {
    width: 21,
    height: 21,
    viewBox: '0 0 24 24',
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth: 2,
    strokeLinecap: 'round' as const,
    strokeLinejoin: 'round' as const,
    'aria-hidden': true,
  }

  if (name === 'home') {
    return (
      <svg {...common}>
        <path d="M3 10.5 12 3l9 7.5" />
        <path d="M5 9.5V21h14V9.5" />
      </svg>
    )
  }

  if (name === 'users') {
    return (
      <svg {...common}>
        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
        <path d="M16 3.13a4 4 0 0 1 0 7.75" />
      </svg>
    )
  }

  if (name === 'box') {
    return (
      <svg {...common}>
        <path d="m21 8-9-5-9 5 9 5 9-5Z" />
        <path d="M3 8v8l9 5 9-5V8" />
        <path d="M12 13v8" />
      </svg>
    )
  }

  if (name === 'clock') {
    return (
      <svg {...common}>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3 2" />
      </svg>
    )
  }

  return (
    <svg {...common}>
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-1.7 1.7-.06-.06a1.7 1.7 0 0 0-1.88-.34 1.7 1.7 0 0 0-1.03 1.56V20h-2.4v-.2a1.7 1.7 0 0 0-1.03-1.56 1.7 1.7 0 0 0-1.88.34l-.06.06-1.7-1.7.06-.06A1.7 1.7 0 0 0 8.4 15a1.7 1.7 0 0 0-1.56-1.03H6v-2.4h.84A1.7 1.7 0 0 0 8.4 10a1.7 1.7 0 0 0-.34-1.88L8 8.06l1.7-1.7.06.06a1.7 1.7 0 0 0 1.88.34A1.7 1.7 0 0 0 12.67 5.2V5h2.4v.2a1.7 1.7 0 0 0 1.03 1.56 1.7 1.7 0 0 0 1.88-.34l.06.06 1.7 1.7-.06.06A1.7 1.7 0 0 0 19.4 15Z" />
    </svg>
  )
}

export default function Dashboard({
  user,
  supabase,
  onSignOut,
}: {
  user: string
  supabase: SupabaseClient<any>
  onSignOut?: () => void
}) {
  const [tab, setTab] = useState<Tab>('dashboard')

  const [customers, setCustomers] = useState<Customer[]>([])
  const [orders, setOrders] = useState<Order[]>([])
  const [followUps, setFollowUps] = useState<FollowUp[]>([])
  const [complaints, setComplaints] = useState<Complaint[]>([])
  const [rules, setRules] = useState<AutomationRule[]>([])
  const [settings, setSettings] = useState<UserSettings | null>(null)

  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const [customerSearch, setCustomerSearch] = useState('')
  const [customerStatusFilter, setCustomerStatusFilter] = useState('الكل')
  const [showCustomerForm, setShowCustomerForm] = useState(false)
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null)
  const [customerForm, setCustomerForm] = useState<CustomerForm>(emptyCustomerForm)
  const [savingCustomer, setSavingCustomer] = useState(false)
  const [customerActionError, setCustomerActionError] = useState<string | null>(null)

  const [orderSearch, setOrderSearch] = useState('')
  const [orderStatusFilter, setOrderStatusFilter] = useState('الكل')
  const [showOrderForm, setShowOrderForm] = useState(false)
  const [editingOrder, setEditingOrder] = useState<Order | null>(null)
  const [orderForm, setOrderForm] = useState<OrderForm>(emptyOrderForm)
  const [savingOrder, setSavingOrder] = useState(false)
  const [orderActionError, setOrderActionError] = useState<string | null>(null)

  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)
  const [payments, setPayments] = useState<OrderPayment[]>([])
  const [paymentAmount, setPaymentAmount] = useState('')
  const [paymentNote, setPaymentNote] = useState('')
  const [savingPayment, setSavingPayment] = useState(false)

  const [showFollowUpForm, setShowFollowUpForm] = useState(false)
  const [followUpForm, setFollowUpForm] = useState<FollowUpForm>(emptyFollowUpForm)
  const [savingFollowUp, setSavingFollowUp] = useState(false)

  const [showComplaintForm, setShowComplaintForm] = useState(false)
  const [complaintForm, setComplaintForm] = useState<ComplaintForm>(emptyComplaintForm)
  const [savingComplaint, setSavingComplaint] = useState(false)

  const [settingsSaving, setSettingsSaving] = useState(false)
  const [rulesRunning, setRulesRunning] = useState(false)
  const [stage5Error, setStage5Error] = useState<string | null>(null)

  async function getUserId() {
    const { data, error: authError } = await supabase.auth.getUser()
    if (authError) throw authError

    const userId = data.user?.id
    if (!userId) throw new Error('لا يوجد مستخدم مسجل الدخول.')

    return userId
  }

  async function loadData() {
    setLoading(true)
    setError(null)
    setStage5Error(null)

    try {
      const userId = await getUserId()

      const [
        customersResult,
        ordersResult,
        followUpsResult,
        complaintsResult,
        rulesResult,
        settingsResult,
      ] = await Promise.all([
        supabase
          .from('customers')
          .select('*')
          .is('deleted_at', null)
          .order('created_at', { ascending: false }),

        supabase
          .from('orders')
          .select('*')
          .order('created_at', { ascending: false }),

        supabase
          .from('follow_ups')
          .select('*')
          .order('followed_at', { ascending: false }),

        supabase
          .from('complaints')
          .select('*')
          .order('created_at', { ascending: false }),

        supabase
          .from('automation_rules')
          .select('*')
          .eq('user_id', userId),

        supabase
          .from('user_settings')
          .select('*')
          .eq('user_id', userId)
          .maybeSingle(),
      ])

      if (customersResult.error) throw customersResult.error
      if (ordersResult.error) throw ordersResult.error
      if (followUpsResult.error) throw followUpsResult.error
      if (complaintsResult.error) throw complaintsResult.error
      if (rulesResult.error) throw rulesResult.error
      if (settingsResult.error) throw settingsResult.error

      setCustomers((customersResult.data ?? []) as Customer[])
      setOrders((ordersResult.data ?? []) as Order[])
      setFollowUps((followUpsResult.data ?? []) as FollowUp[])
      setComplaints((complaintsResult.data ?? []) as Complaint[])
      setRules((rulesResult.data ?? []) as AutomationRule[])

      if (settingsResult.data) {
        setSettings(settingsResult.data as UserSettings)
      } else {
        setSettings({
          user_id: userId,
          notifications_enabled: true,
          contacts_sync_enabled: true,
          morning_summary_enabled: true,
          weekly_summary_enabled: true,
          session_persistence_enabled: true,
          dark_mode_enabled: false,
          monthly_customer_goal: 10,
          updated_at: new Date().toISOString(),
        })
      }
    } catch (loadError) {
      console.error('Dashboard data load failed:', loadError)
      setError('تعذر تحميل بيانات لوحة التشغيل. حاول مرة أخرى.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    void loadData()
  }, [supabase])

  const today = todayLocal()

  const todayFollowUps = useMemo(
    () =>
      customers.filter(
        (customer) => customer.next_follow_up === today,
      ),
    [customers, today],
  )

  const prospects = useMemo(
    () =>
      customers.filter((customer) =>
        ['مهتم', 'تفاوض', 'متابعة'].includes(customer.status),
      ),
    [customers],
  )

  const actualCustomers = useMemo(
    () =>
      customers.filter(
        (customer) =>
          customer.status === 'اشترى' ||
          orders.some((order) => order.customer_id === customer.id),
      ),
    [customers, orders],
  )

  const activeOrders = orders.filter(
    (order) => order.status !== 'تم التسليم',
  )

  const deliveredOrders = orders.filter(
    (order) => order.status === 'تم التسليم',
  )

  const upcomingDeliveries = useMemo(
    () =>
      orders
        .filter(
          (order) =>
            order.delivery_date &&
            order.delivery_date >= today &&
            order.status !== 'تم التسليم',
        )
        .sort((a, b) =>
          `${a.delivery_date}${a.delivery_time ?? ''}`.localeCompare(
            `${b.delivery_date}${b.delivery_time ?? ''}`,
          ),
        )
        .slice(0, 4),
    [orders, today],
  )

  const customerById = useMemo(
    () => new Map(customers.map((customer) => [customer.id, customer])),
    [customers],
  )

  const filteredCustomers = useMemo(() => {
    const query = customerSearch.trim().toLowerCase()

    return customers.filter((customer) => {
      const matchesSearch =
        !query ||
        [
          customer.name,
          customer.phone,
          customer.request,
          customer.address,
        ].some((value) => value?.toLowerCase().includes(query))

      const matchesStatus =
        customerStatusFilter === 'الكل' ||
        customer.status === customerStatusFilter

      return matchesSearch && matchesStatus
    })
  }, [customers, customerSearch, customerStatusFilter])

  const filteredOrders = useMemo(() => {
    const query = orderSearch.trim().toLowerCase()

    return orders.filter((order) => {
      const customer = customerById.get(order.customer_id)

      const matchesSearch =
        !query ||
        [
          order.product,
          customer?.name,
          customer?.phone,
          order.fabric,
          order.size,
        ].some((value) => value?.toLowerCase().includes(query))

      const matchesStatus =
        orderStatusFilter === 'الكل' ||
        order.status === orderStatusFilter

      return matchesSearch && matchesStatus
    })
  }, [orders, customerById, orderSearch, orderStatusFilter])

  const enabledRules = useMemo(
    () => new Map(rules.map((rule) => [rule.rule_key, rule.enabled])),
    [rules],
  )

  const activeComplaints = complaints.filter(
    (complaint) => complaint.status !== 'تم الحل',
  )

  function openNewCustomer() {
    setEditingCustomer(null)
    setCustomerForm(emptyCustomerForm)
    setCustomerActionError(null)
    setShowCustomerForm(true)
  }

  function openEditCustomer(customer: Customer) {
    setEditingCustomer(customer)

    setCustomerForm({
      name: customer.name,
      phone: customer.phone ?? '',
      status: customer.status,
      source: customer.source ?? '',
      request: customer.request ?? '',
      address: customer.address ?? '',
      note: customer.note ?? '',
      next_follow_up: customer.next_follow_up ?? '',
      next_follow_up_time: customer.next_follow_up_time
        ? customer.next_follow_up_time.slice(0, 5)
        : '',
      follow_up_repeat: customer.follow_up_repeat ?? 'بدون تكرار',
      lost_reason: customer.lost_reason ?? '',
    })

    setCustomerActionError(null)
    setShowCustomerForm(true)
  }

  async function saveCustomer(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setCustomerActionError(null)

    const name = customerForm.name.trim()
    const phone = normalizeYemeniPhone(customerForm.phone)

    if (!name) {
      setCustomerActionError('اسم العميل مطلوب.')
      return
    }

    if (!isValidYemeniPhone(phone)) {
      setCustomerActionError(
        'رقم الجوال يجب أن يكون رقمًا يمنيًا بصيغة +9677XXXXXXXX.',
      )
      return
    }

    setSavingCustomer(true)

    try {
      const userId = await getUserId()

      const payload = {
        user_id: userId,
        name,
        phone,
        status: customerForm.status,
        source: customerForm.source || null,
        request: customerForm.request.trim() || null,
        address: customerForm.address.trim() || null,
        note: customerForm.note.trim() || null,
        next_follow_up: customerForm.next_follow_up || null,
        next_follow_up_time: customerForm.next_follow_up_time || null,
        follow_up_repeat:
          customerForm.follow_up_repeat === 'بدون تكرار'
            ? null
            : customerForm.follow_up_repeat,
        lost_reason: customerForm.lost_reason.trim() || null,
      }

      if (editingCustomer) {
        const { data, error: updateError } = await supabase
          .from('customers')
          .update(payload)
          .eq('id', editingCustomer.id)
          .select('*')
          .single()

        if (updateError) throw updateError

        setCustomers((current) =>
          current.map((customer) =>
            customer.id === editingCustomer.id
              ? (data as Customer)
              : customer,
          ),
        )
      } else {
        const { data, error: insertError } = await supabase
          .from('customers')
          .insert(payload)
          .select('*')
          .single()

        if (insertError) throw insertError

        setCustomers((current) => [data as Customer, ...current])
      }

      setShowCustomerForm(false)
      setEditingCustomer(null)
      setCustomerForm(emptyCustomerForm)
    } catch (saveError) {
      console.error('Customer save failed:', saveError)
      setCustomerActionError(
        'تعذر حفظ بيانات العميل. تحقق من الاتصال ثم حاول مرة أخرى.',
      )
    } finally {
      setSavingCustomer(false)
    }
  }

  async function archiveCustomer(customer: Customer) {
    if (!window.confirm(`هل تريد أرشفة العميل «${customer.name}»؟`)) {
      return
    }

    setCustomerActionError(null)

    try {
      const { error: archiveError } = await supabase
        .from('customers')
        .update({ deleted_at: new Date().toISOString() })
        .eq('id', customer.id)

      if (archiveError) throw archiveError

      setCustomers((current) =>
        current.filter((item) => item.id !== customer.id),
      )
    } catch (archiveError) {
      console.error('Customer archive failed:', archiveError)
      setCustomerActionError('تعذر أرشفة العميل.')
    }
  }

  function openNewOrder(customerId = '') {
    setEditingOrder(null)
    setOrderForm({
      ...emptyOrderForm,
      customer_id: customerId,
    })
    setOrderActionError(null)
    setShowOrderForm(true)
  }

  function openEditOrder(order: Order) {
    setEditingOrder(order)

    setOrderForm({
      customer_id: order.customer_id,
      product: order.product,
      total: String(order.total ?? ''),
      deposit: String(order.deposit ?? ''),
      status: order.status,
      delivery_date: order.delivery_date ?? '',
      delivery_time: formatTime(order.delivery_time),
      reminder_days: String(order.reminder_days ?? 1),
      source: order.source ?? '',
      size: order.size ?? '',
      fabric: order.fabric ?? '',
      note: order.note ?? '',
    })

    setOrderActionError(null)
    setShowOrderForm(true)
  }

  async function saveOrder(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setOrderActionError(null)

    const total = Number(orderForm.total)
    const deposit = Number(orderForm.deposit || 0)
    const reminderDays = Number(orderForm.reminder_days || 1)

    if (!orderForm.customer_id) {
      setOrderActionError('اختر العميل أولًا.')
      return
    }

    if (!orderForm.product.trim()) {
      setOrderActionError('اسم المنتج أو الطلب مطلوب.')
      return
    }

    if (!Number.isFinite(total) || total < 0) {
      setOrderActionError('إجمالي الطلب غير صحيح.')
      return
    }

    if (
      !Number.isFinite(deposit) ||
      deposit < 0 ||
      deposit > total
    ) {
      setOrderActionError(
        'العربون يجب أن يكون بين صفر وإجمالي الطلب.',
      )
      return
    }

    if (
      !Number.isInteger(reminderDays) ||
      reminderDays < 0
    ) {
      setOrderActionError(
        'أيام التذكير يجب أن تكون رقمًا صحيحًا موجبًا أو صفرًا.',
      )
      return
    }

    setSavingOrder(true)

    try {
      const userId = await getUserId()

      const payload = {
        user_id: userId,
        customer_id: orderForm.customer_id,
        product: orderForm.product.trim(),
        total,
        deposit,
        status: orderForm.status,
        delivery_date: orderForm.delivery_date || null,
        delivery_time: orderForm.delivery_time || null,
        reminder_days: reminderDays,
        source: orderForm.source || null,
        size: orderForm.size.trim() || null,
        fabric: orderForm.fabric.trim() || null,
        note: orderForm.note.trim() || null,
      }

      if (editingOrder) {
        const { data, error: updateError } = await supabase
          .from('orders')
          .update(payload)
          .eq('id', editingOrder.id)
          .select('*')
          .single()

        if (updateError) throw updateError

        setOrders((current) =>
          current.map((order) =>
            order.id === editingOrder.id
              ? (data as Order)
              : order,
          ),
        )
      } else {
        const { data, error: insertError } = await supabase
          .from('orders')
          .insert(payload)
          .select('*')
          .single()

        if (insertError) throw insertError

        setOrders((current) => [data as Order, ...current])
      }

      setShowOrderForm(false)
      setEditingOrder(null)
      setOrderForm(emptyOrderForm)
    } catch (saveError) {
      console.error('Order save failed:', saveError)
      setOrderActionError(
        'تعذر حفظ الطلب. تحقق من الاتصال ثم حاول مرة أخرى.',
      )
    } finally {
      setSavingOrder(false)
    }
  }

  async function changeOrderStatus(
    order: Order,
    status: string,
  ) {
    try {
      const { data, error: updateError } = await supabase
        .from('orders')
        .update({ status })
        .eq('id', order.id)
        .select('*')
        .single()

      if (updateError) throw updateError

      setOrders((current) =>
        current.map((item) =>
          item.id === order.id ? (data as Order) : item,
        ),
      )

      setSelectedOrder(data as Order)
    } catch (statusError) {
      console.error('Order status update failed:', statusError)
      setOrderActionError('تعذر تحديث حالة الطلب.')
    }
  }

  async function openOrderDetails(order: Order) {
    setSelectedOrder(order)
    setPaymentAmount('')
    setPaymentNote('')
    setOrderActionError(null)

    try {
      const { data, error: paymentsError } = await supabase
        .from('order_payments')
        .select('id,order_id,amount,paid_at,note')
        .eq('order_id', order.id)
        .order('paid_at', { ascending: false })

      if (paymentsError) throw paymentsError

      setPayments((data ?? []) as OrderPayment[])
    } catch (paymentsError) {
      console.error(
        'Order payments load failed:',
        paymentsError,
      )
      setPayments([])
      setOrderActionError(
        'تعذر تحميل دفعات الطلب.',
      )
    }
  }

  async function addPayment(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()

    if (!selectedOrder) return

    const amount = Number(paymentAmount)
    const paidAlready = payments.reduce(
      (sum, payment) => sum + Number(payment.amount),
      0,
    )
    const remaining = Math.max(
      0,
      Number(selectedOrder.total) - paidAlready,
    )

    if (!Number.isFinite(amount) || amount <= 0) {
      setOrderActionError(
        'مبلغ الدفعة يجب أن يكون أكبر من صفر.',
      )
      return
    }

    if (amount > remaining) {
      setOrderActionError(
        'مبلغ الدفعة أكبر من المتبقي على الطلب.',
      )
      return
    }

    setSavingPayment(true)
    setOrderActionError(null)

    try {
      const userId = await getUserId()

      const { data, error: insertError } = await supabase
        .from('order_payments')
        .insert({
          user_id: userId,
          order_id: selectedOrder.id,
          amount,
          note: paymentNote.trim() || null,
        })
        .select(
          'id,order_id,amount,paid_at,note',
        )
        .single()

      if (insertError) throw insertError

      setPayments((current) => [
        data as OrderPayment,
        ...current,
      ])

      setPaymentAmount('')
      setPaymentNote('')
    } catch (paymentError) {
      console.error('Payment save failed:', paymentError)
      setOrderActionError('تعذر تسجيل الدفعة.')
    } finally {
      setSavingPayment(false)
    }
  }

  function openNewFollowUp(customerId = '') {
    setFollowUpForm({
      ...emptyFollowUpForm,
      customer_id: customerId,
      next_follow_up: today,
    })
    setShowFollowUpForm(true)
    setStage5Error(null)
  }

  async function saveFollowUp(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setStage5Error(null)

    if (!followUpForm.customer_id) {
      setStage5Error('اختر العميل أولًا.')
      return
    }

    if (!followUpForm.result.trim() && !followUpForm.note.trim()) {
      setStage5Error('أدخل نتيجة المتابعة أو ملاحظة.')
      return
    }

    setSavingFollowUp(true)

    try {
      const userId = await getUserId()

      const payload = {
        user_id: userId,
        customer_id: followUpForm.customer_id,
        result: followUpForm.result.trim() || null,
        note: followUpForm.note.trim() || null,
        next_follow_up:
          followUpForm.next_follow_up || null,
        next_follow_up_time:
          followUpForm.next_follow_up_time || null,
        status: followUpForm.status,
      }

      const { data, error: insertError } = await supabase
        .from('follow_ups')
        .insert(payload)
        .select('*')
        .single()

      if (insertError) throw insertError

      const { data: customer, error: customerError } =
        await supabase
          .from('customers')
          .update({
            next_follow_up:
              followUpForm.next_follow_up || null,
            next_follow_up_time:
              followUpForm.next_follow_up_time || null,
          })
          .eq('id', followUpForm.customer_id)
          .select('*')
          .single()

      if (customerError) throw customerError

      setFollowUps((current) => [
        data as FollowUp,
        ...current,
      ])

      setCustomers((current) =>
        current.map((item) =>
          item.id === followUpForm.customer_id
            ? (customer as Customer)
            : item,
        ),
      )

      setShowFollowUpForm(false)
      setFollowUpForm(emptyFollowUpForm)
    } catch (followUpError) {
      console.error(
        'Follow-up save failed:',
        followUpError,
      )
      setStage5Error('تعذر حفظ المتابعة.')
    } finally {
      setSavingFollowUp(false)
    }
  }

  async function completeFollowUp(followUp: FollowUp) {
    try {
      const { data, error: updateError } = await supabase
        .from('follow_ups')
        .update({ status: 'تمت' })
        .eq('id', followUp.id)
        .select('*')
        .single()

      if (updateError) throw updateError

      setFollowUps((current) =>
        current.map((item) =>
          item.id === followUp.id
            ? (data as FollowUp)
            : item,
        ),
      )
    } catch (completeError) {
      console.error(
        'Follow-up completion failed:',
        completeError,
      )
      setStage5Error('تعذر تحديث حالة المتابعة.')
    }
  }

  function openNewComplaint(customerId = '') {
    setComplaintForm({
      customer_id: customerId,
      complaint: '',
    })
    setShowComplaintForm(true)
    setStage5Error(null)
  }

  async function saveComplaint(
    event: FormEvent<HTMLFormElement>,
  ) {
    event.preventDefault()
    setStage5Error(null)

    if (!complaintForm.customer_id) {
      setStage5Error('اختر العميل أولًا.')
      return
    }

    if (!complaintForm.complaint.trim()) {
      setStage5Error('اكتب نص الشكوى.')
      return
    }

    setSavingComplaint(true)

    try {
      const userId = await getUserId()

      const { data, error: insertError } = await supabase
        .from('complaints')
        .insert({
          user_id: userId,
          customer_id: complaintForm.customer_id,
          complaint: complaintForm.complaint.trim(),
          status: 'قيد المعالجة',
        })
        .select('*')
        .single()

      if (insertError) throw insertError

      setComplaints((current) => [
        data as Complaint,
        ...current,
      ])

      setShowComplaintForm(false)
      setComplaintForm(emptyComplaintForm)
    } catch (complaintError) {
      console.error(
        'Complaint save failed:',
        complaintError,
      )
      setStage5Error('تعذر تسجيل الشكوى.')
    } finally {
      setSavingComplaint(false)
    }
  }

  async function toggleComplaint(complaint: Complaint) {
    try {
      const resolved =
        complaint.status !== 'تم الحل'

      const { data, error: updateError } =
        await supabase
          .from('complaints')
          .update({
            status: resolved
              ? 'تم الحل'
              : 'قيد المعالجة',
            resolved_at: resolved
              ? new Date().toISOString()
              : null,
          })
          .eq('id', complaint.id)
          .select('*')
          .single()

      if (updateError) throw updateError

      setComplaints((current) =>
        current.map((item) =>
          item.id === complaint.id
            ? (data as Complaint)
            : item,
        ),
      )
    } catch (complaintError) {
      console.error(
        'Complaint status update failed:',
        complaintError,
      )
      setStage5Error(
        'تعذر تحديث حالة الشكوى.',
      )
    }
  }

  async function saveRule(
    ruleKey: string,
    enabled: boolean,
  ) {
    try {
      const userId = await getUserId()

      const { data, error: upsertError } =
        await supabase
          .from('automation_rules')
          .upsert(
            {
              user_id: userId,
              rule_key: ruleKey,
              enabled,
              updated_at:
                new Date().toISOString(),
            },
            {
              onConflict: 'user_id,rule_key',
            },
          )
          .select('*')
          .single()

      if (upsertError) throw upsertError

      setRules((current) => {
        const exists = current.some(
          (rule) => rule.rule_key === ruleKey,
        )

        if (!exists) {
          return [
            ...current,
            data as AutomationRule,
          ]
        }

        return current.map((rule) =>
          rule.rule_key === ruleKey
            ? (data as AutomationRule)
            : rule,
        )
      })
    } catch (ruleError) {
      console.error(
        'Automation rule save failed:',
        ruleError,
      )
      setStage5Error(
        'تعذر حفظ إعداد القاعدة.',
      )
    }
  }

  async function updateSettings(
    patch: Partial<UserSettings>,
  ) {
    if (!settings) return

    setSettingsSaving(true)
    setStage5Error(null)

    try {
      const userId = await getUserId()

      const payload = {
        ...settings,
        ...patch,
        user_id: userId,
        updated_at: new Date().toISOString(),
      }

      const { data, error: upsertError } =
        await supabase
          .from('user_settings')
          .upsert(payload, {
            onConflict: 'user_id',
          })
          .select('*')
          .single()

      if (upsertError) throw upsertError

      setSettings(data as UserSettings)
    } catch (settingsError) {
      console.error(
        'Settings update failed:',
        settingsError,
      )
      setStage5Error(
        'تعذر حفظ الإعداد. حاول مرة أخرى.',
      )
    } finally {
      setSettingsSaving(false)
    }
  }

  async function insertRuleFollowUp(
    customerId: string,
    note: string,
    nextDate: string,
  ) {
    try {
      const userId = await getUserId()

      const { data, error } = await supabase
        .from('follow_ups')
        .insert({
          user_id: userId,
          customer_id: customerId,
          result: null,
          note,
          next_follow_up: nextDate,
          next_follow_up_time: null,
          status: 'مجدولة',
        })
        .select('*')
        .single()

      if (error) throw error

      setFollowUps((current) => [
        data as FollowUp,
        ...current,
      ])
    } catch (ruleFollowUpError) {
      console.error(
        'Rule follow-up creation failed:',
        ruleFollowUpError,
      )
    }
  }

  async function runAutomationRules() {
    if (rulesRunning) return

    setRulesRunning(true)
    setStage5Error(null)

    try {
      const enabled = (key: string) =>
        enabledRules.get(key) ?? true

      let changedCustomers = [...customers]
      let changedOrders = [...orders]
      let changedCount = 0

      for (const order of changedOrders) {
        if (
          enabled('b') &&
          order.status === 'تم التسليم' &&
          order.delivery_date &&
          order.delivery_date <= today
        ) {
          const customer =
            changedCustomers.find(
              (item) =>
                item.id === order.customer_id,
            )

          if (
            customer &&
            customer.status !== 'اشترى'
          ) {
            const { data, error } =
              await supabase
                .from('customers')
                .update({
                  status: 'اشترى',
                })
                .eq('id', customer.id)
                .select('*')
                .single()

            if (error) throw error

            changedCustomers =
              changedCustomers.map((item) =>
                item.id === customer.id
                  ? (data as Customer)
                  : item,
              )

            changedCount++
          }
        }

        if (
          enabled('e') &&
          order.status === 'جديد' &&
          Number(order.deposit) > 0
        ) {
          const { data, error } =
            await supabase
              .from('orders')
              .update({
                status: 'قيد التفصيل',
              })
              .eq('id', order.id)
              .select('*')
              .single()

          if (error) throw error

          changedOrders =
            changedOrders.map((item) =>
              item.id === order.id
                ? (data as Order)
                : item,
            )

          changedCount++
        }

        if (
          order.status === 'تم التسليم' &&
          order.delivery_date
        ) {
          const daysSinceDelivery =
            dateDifferenceInDays(
              order.delivery_date,
            )

          if (
            enabled('c') &&
            Number(order.deposit) <
              Number(order.total)
          ) {
            const customer =
              changedCustomers.find(
                (item) =>
                  item.id === order.customer_id,
              )

            if (customer) {
              const { data, error } =
                await supabase
                  .from('customers')
                  .update({
                    next_follow_up: today,
                    next_follow_up_time: null,
                  })
                  .eq('id', customer.id)
                  .select('*')
                  .single()

              if (error) throw error

              changedCustomers =
                changedCustomers.map((item) =>
                  item.id === customer.id
                    ? (data as Customer)
                    : item,
                )

              await insertRuleFollowUp(
                customer.id,
                'متابعة تحصيل اليوم',
                today,
              )

              changedCount++
            }
          }

          if (
            enabled('f') &&
            daysSinceDelivery >= 2 &&
            Number(order.deposit) >=
              Number(order.total)
          ) {
            const customer =
              changedCustomers.find(
                (item) =>
                  item.id === order.customer_id,
              )

            if (
              customer &&
              !customer.next_follow_up
            ) {
              const { data, error } =
                await supabase
                  .from('customers')
                  .update({
                    next_follow_up: today,
                    next_follow_up_time: null,
                  })
                  .eq('id', customer.id)
                  .select('*')
                  .single()

              if (error) throw error

              changedCustomers =
                changedCustomers.map((item) =>
                  item.id === customer.id
                    ? (data as Customer)
                    : item,
                )

              await insertRuleFollowUp(
                customer.id,
                'اطلب رأي العميل بعد التسليم',
                today,
              )

              changedCount++
            }
          }
        }
      }

      for (const customer of changedCustomers) {
        if (
          enabled('a') &&
          customer.status === 'مهتم' &&
          customer.next_follow_up &&
          dateDifferenceInDays(
            customer.next_follow_up,
          ) >= 7
        ) {
          const { data, error } =
            await supabase
              .from('customers')
              .update({
                status: 'متابعة',
                next_follow_up: today,
              })
              .eq('id', customer.id)
              .select('*')
              .single()

          if (error) throw error

          changedCustomers =
            changedCustomers.map((item) =>
              item.id === customer.id
                ? (data as Customer)
                : item,
            )

          changedCount++
        }

        if (
          enabled('d') &&
          customer.next_follow_up &&
          dateDifferenceInDays(
            customer.next_follow_up,
          ) > 3
        ) {
          const { data, error } =
            await supabase
              .from('customers')
              .update({
                next_follow_up: today,
              })
              .eq('id', customer.id)
              .select('*')
              .single()

          if (error) throw error

          changedCustomers =
            changedCustomers.map((item) =>
              item.id === customer.id
                ? (data as Customer)
                : item,
            )

          changedCount++
        }

        if (
          enabled('g') &&
          customer.status === 'غير مهتم' &&
          customer.next_follow_up
        ) {
          const { data, error } =
            await supabase
              .from('customers')
              .update({
                next_follow_up: null,
                next_follow_up_time: null,
              })
              .eq('id', customer.id)
              .select('*')
              .single()

          if (error) throw error

          changedCustomers =
            changedCustomers.map((item) =>
              item.id === customer.id
                ? (data as Customer)
                : item,
            )

          changedCount++
        }

        if (
          enabled('h') &&
          customer.status === 'اشترى' &&
          !customer.next_follow_up
        ) {
          const nextDate = addDays(180)

          const { data, error } =
            await supabase
              .from('customers')
              .update({
                next_follow_up: nextDate,
              })
              .eq('id', customer.id)
              .select('*')
              .single()

          if (error) throw error

          changedCustomers =
            changedCustomers.map((item) =>
              item.id === customer.id
                ? (data as Customer)
                : item,
            )

          await insertRuleFollowUp(
            customer.id,
            'متابعة ضمان وصيانة بعد 6 أشهر',
            nextDate,
          )

          changedCount++
        }
      }

      setCustomers(changedCustomers)
      setOrders(changedOrders)

      setStage5Error(
        changedCount > 0
          ? `تم تشغيل القواعد وتطبيق ${changedCount} إجراء.`
          : 'لا يوجد عملاء أو طلبات تطابق القواعد الحالية.',
      )
    } catch (rulesError) {
      console.error(
        'Automation rules execution failed:',
        rulesError,
      )
      setStage5Error(
        'تعذر تشغيل القواعد التلقائية.',
      )
    } finally {
      setRulesRunning(false)
    }
  }

  return (
    <div className="asalah-shell" dir="rtl">
      <header className="asalah-header">
        <div className="brand-block">
          <div className="brand-mark">أ</div>
          <div>
            <div className="eyebrow">
              لوحة التشغيل
            </div>
            <h1>مفروشات الأصالة</h1>
            <small>{user}</small>
          </div>
        </div>

        <span className="preview-pill">
          نسخة تشغيل
        </span>
      </header>

      {error && (
        <div className="asalah-alert" role="alert">
          {error}
        </div>
      )}

      {customerActionError &&
        tab === 'customers' && (
          <div
            className="asalah-alert"
            role="alert"
          >
            {customerActionError}
          </div>
        )}

      {orderActionError &&
        tab === 'orders' && (
          <div
            className="asalah-alert"
            role="alert"
          >
            {orderActionError}
          </div>
        )}

      {stage5Error &&
        (tab === 'followups' ||
          tab === 'settings') && (
          <div
            className="asalah-alert"
            role="alert"
          >
            {stage5Error}
          </div>
        )}

      {tab === 'dashboard' && (
        <main>
          <section className="welcome-card">
            <div className="welcome-eyebrow">
              مركز التشغيل
            </div>

            <h2>
              كل ما يحتاجه العمل في شاشة واحدة
            </h2>

            <p>
              متابعة العملاء، تنفيذ الطلبات،
              التسليم، والمتابعات — مع واجهة
              عملية وسريعة للاستخدام اليومي.
            </p>
          </section>

          <section className="stats-grid">
            <article className="stat-card">
              <div className="stat-label">
                عملاء محتملون / قيد المتابعة
              </div>
              <strong>
                {loading ? '—' : prospects.length}
              </strong>
              <small>
                مهتم • تفاوض • متابعة
              </small>
            </article>

            <article className="stat-card">
              <div className="stat-label">
                العملاء الفعليون
              </div>
              <strong>
                {loading
                  ? '—'
                  : actualCustomers.length}
              </strong>
              <small>
                اشتروا أو لديهم طلب
              </small>
            </article>

            <article className="stat-card">
              <div className="stat-label">
                الطلبيات
              </div>
              <strong>
                {loading ? '—' : orders.length}
              </strong>
              <small>
                قيد التنفيذ:{' '}
                {activeOrders.length} • تم
                التسليم: {deliveredOrders.length}
              </small>
            </article>

            <article className="stat-card">
              <div className="stat-label">
                متابعات مستحقة اليوم
              </div>
              <strong>
                {loading
                  ? '—'
                  : todayFollowUps.length}
              </strong>
              <small>
                الشكاوى المفتوحة:{' '}
                {activeComplaints.length}
              </small>
            </article>
          </section>

          <section className="section-heading">
            <h2>إجراءات سريعة</h2>
          </section>

          <section className="quick-actions">
            <button onClick={openNewCustomer}>
              <span className="quick-icon">
                ＋
              </span>
              <span>عميل جديد</span>
            </button>

            <button
              onClick={() => {
                setTab('orders')
                openNewOrder()
              }}
            >
              <span className="quick-icon">
                ▣
              </span>
              <span>طلب جديد</span>
            </button>

            <button
              onClick={() => setTab('followups')}
            >
              <span className="quick-icon">
                ◷
              </span>
              <span>المتابعات</span>
            </button>
          </section>

          <section className="section-heading with-action">
            <h2>تقدم الطلبات</h2>

            <button
              className="asalah-button secondary small"
              onClick={() => setTab('orders')}
            >
              عرض الطلبات
            </button>
          </section>

          <section className="surface-card pipeline-card">
            <div className="pipeline-grid">
              {orderStages.map((stage) => (
                <div
                  className="pipeline-stage"
                  key={stage}
                >
                  <strong>
                    {loading
                      ? '—'
                      : orders.filter(
                          (order) =>
                            order.status === stage,
                        ).length}
                  </strong>

                  <span>{stage}</span>
                </div>
              ))}
            </div>
          </section>

          <section className="section-heading with-action">
            <h2>التسليمات القريبة</h2>

            <button
              className="asalah-button secondary small"
              onClick={() => setTab('orders')}
            >
              عرض الطلبات
            </button>
          </section>

          <section className="surface-card list-card">
            {loading ? (
              <div className="empty-state">
                جاري تحميل البيانات…
              </div>
            ) : upcomingDeliveries.length === 0 ? (
              <div className="empty-state">
                لا توجد تسليمات قريبة.
              </div>
            ) : (
              upcomingDeliveries.map((order) => {
                const customer =
                  customerById.get(
                    order.customer_id,
                  )

                return (
                  <div
                    className="list-row"
                    key={order.id}
                  >
                    <div className="list-main">
                      <strong>
                        {order.product}
                      </strong>
                      <span>
                        {customer?.name ||
                          'عميل غير معروف'}
                      </span>
                    </div>

                    <div className="list-side">
                      <span className="status-tag blue">
                        {formatDate(
                          order.delivery_date,
                        )}
                      </span>

                      <small>
                        {formatTime(
                          order.delivery_time,
                        )}
                      </small>
                    </div>
                  </div>
                )
              })
            )}
          </section>
        </main>
      )}

      {tab === 'customers' && (
        <main>
          <section className="section-heading customer-title">
            <div>
              <div className="eyebrow">
                إدارة العملاء
              </div>
          
