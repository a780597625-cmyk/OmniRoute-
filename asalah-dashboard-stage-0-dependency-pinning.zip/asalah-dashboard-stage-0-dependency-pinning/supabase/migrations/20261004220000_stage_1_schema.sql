create extension if not exists pgcrypto;

create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  phone text,
  status text not null default 'مهتم',
  next_follow_up date,
  next_follow_up_time time,
  follow_up_repeat text,
  source text,
  request text,
  address text,
  note text,
  lost_reason text,
  deleted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  customer_id uuid not null references public.customers(id) on delete cascade,
  product text not null,
  total numeric(12,2) not null default 0,
  deposit numeric(12,2) not null default 0,
  status text not null default 'جديد',
  delivery_date date,
  delivery_time time,
  reminder_days integer not null default 1,
  source text,
  size text,
  fabric text,
  note text,
  attachment_path text,
  rating smallint,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.order_payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  order_id uuid not null references public.orders(id) on delete cascade,
  amount numeric(12,2) not null default 0,
  paid_at timestamptz not null default now(),
  note text,
  created_at timestamptz not null default now()
);

create table if not exists public.follow_ups (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  customer_id uuid not null references public.customers(id) on delete cascade,
  followed_at timestamptz not null default now(),
  result text,
  note text,
  next_follow_up date,
  next_follow_up_time time,
  status text not null default 'مجدولة'
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  category text not null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.whatsapp_templates (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  message text not null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.complaints (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  customer_id uuid not null references public.customers(id) on delete cascade,
  complaint text not null,
  status text not null default 'قيد المعالجة',
  created_at timestamptz not null default now(),
  resolved_at timestamptz,
  updated_at timestamptz not null default now()
);

create table if not exists public.automation_rules (
  user_id uuid not null references auth.users(id) on delete cascade,
  rule_key text not null,
  enabled boolean not null default true,
  updated_at timestamptz not null default now(),
  primary key (user_id, rule_key)
);

create table if not exists public.user_settings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  notifications_enabled boolean not null default true,
  contacts_sync_enabled boolean not null default true,
  morning_summary_enabled boolean not null default true,
  weekly_summary_enabled boolean not null default true,
  session_persistence_enabled boolean not null default true,
  dark_mode_enabled boolean not null default false,
  monthly_customer_goal integer not null default 10,
  updated_at timestamptz not null default now()
);

create index if not exists customers_user_id_idx on public.customers(user_id);
create index if not exists customers_phone_idx on public.customers(user_id, phone);
create index if not exists customers_follow_up_idx on public.customers(user_id, next_follow_up);
create index if not exists customers_deleted_at_idx on public.customers(user_id, deleted_at);
create index if not exists orders_user_id_idx on public.orders(user_id);
create index if not exists orders_customer_id_idx on public.orders(customer_id);
create index if not exists orders_status_idx on public.orders(user_id, status);
create index if not exists orders_delivery_idx on public.orders(user_id, delivery_date);
create index if not exists payments_order_id_idx on public.order_payments(order_id);
create index if not exists followups_customer_id_idx on public.follow_ups(customer_id);
create index if not exists followups_next_idx on public.follow_ups(user_id, next_follow_up);
create index if not exists products_user_id_idx on public.products(user_id);
create index if not exists complaints_customer_id_idx on public.complaints(customer_id);
create index if not exists complaints_status_idx on public.complaints(user_id, status);

alter table public.customers enable row level security;
alter table public.orders enable row level security;
alter table public.order_payments enable row level security;
alter table public.follow_ups enable row level security;
alter table public.products enable row level security;
alter table public.whatsapp_templates enable row level security;
alter table public.complaints enable row level security;
alter table public.automation_rules enable row level security;
alter table public.user_settings enable row level security;

drop policy if exists "customers own rows" on public.customers;
drop policy if exists "orders own rows" on public.orders;
drop policy if exists "order payments own rows" on public.order_payments;
drop policy if exists "followups own rows" on public.follow_ups;
drop policy if exists "products own rows" on public.products;
drop policy if exists "whatsapp templates own rows" on public.whatsapp_templates;
drop policy if exists "complaints own rows" on public.complaints;
drop policy if exists "automation rules own rows" on public.automation_rules;
drop policy if exists "user settings own row" on public.user_settings;

create policy "customers own rows" on public.customers for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "orders own rows" on public.orders for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "order payments own rows" on public.order_payments for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "followups own rows" on public.follow_ups for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "products own rows" on public.products for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "whatsapp templates own rows" on public.whatsapp_templates for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "complaints own rows" on public.complaints for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "automation rules own rows" on public.automation_rules for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "user settings own row" on public.user_settings for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end
$$;

drop trigger if exists customers_updated_at on public.customers;
drop trigger if exists orders_updated_at on public.orders;
drop trigger if exists products_updated_at on public.products;
drop trigger if exists whatsapp_templates_updated_at on public.whatsapp_templates;
drop trigger if exists complaints_updated_at on public.complaints;
drop trigger if exists automation_rules_updated_at on public.automation_rules;
drop trigger if exists user_settings_updated_at on public.user_settings;

create trigger customers_updated_at before update on public.customers for each row execute function public.set_updated_at();
create trigger orders_updated_at before update on public.orders for each row execute function public.set_updated_at();
create trigger products_updated_at before update on public.products for each row execute function public.set_updated_at();
create trigger whatsapp_templates_updated_at before update on public.whatsapp_templates for each row execute function public.set_updated_at();
create trigger complaints_updated_at before update on public.complaints for each row execute function public.set_updated_at();
create trigger automation_rules_updated_at before update on public.automation_rules for each row execute function public.set_updated_at();
create trigger user_settings_updated_at before update on public.user_settings for each row execute function public.set_updated_at();
