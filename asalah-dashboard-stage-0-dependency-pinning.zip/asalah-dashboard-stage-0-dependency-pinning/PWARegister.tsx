'use client'

import { useEffect } from 'react'

const SW_URL = '/service-worker.js'
const RELOAD_KEY = 'asalah-pwa-reloaded-v2'

export default function PWARegister() {
  useEffect(() => {
    if (!('serviceWorker' in navigator)) return

    let refreshing = false

    const onControllerChange = () => {
      if (refreshing || sessionStorage.getItem(RELOAD_KEY) === '1') return
      refreshing = true
      sessionStorage.setItem(RELOAD_KEY, '1')
      window.location.reload()
    }

    navigator.serviceWorker.addEventListener('controllerchange', onControllerChange)

    navigator.serviceWorker.register(SW_URL, { updateViaCache: 'none' })
      .then((registration) => registration.update())
      .catch((error) => console.error('[PWA] Service worker registration failed:', error))

    return () => navigator.serviceWorker.removeEventListener('controllerchange', onControllerChange)
  }, [])

  return null
}
