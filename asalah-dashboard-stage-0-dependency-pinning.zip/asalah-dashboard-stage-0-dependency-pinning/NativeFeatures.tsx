import { useState } from 'react'
import { Capacitor } from '@capacitor/core'
import { Contacts } from '@capacitor-community/contacts'

export default function NativeFeatures() {
  const [contactName, setContactName] = useState<string | null>(null)
  const [contactPhone, setContactPhone] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  if (!Capacitor.isNativePlatform()) {
    return null
  }

  async function pickContact() {
    setError(null)

    try {
      const { contact } = await Contacts.pickContact()
      const phone = contact?.phones?.[0]?.number ?? null
      const name = contact?.name
        ? `${contact.name.given ?? ''} ${contact.name.family ?? ''}`.trim()
        : null

      setContactName(name || 'جهة اتصال بدون اسم')
      setContactPhone(phone)
    } catch (pickError) {
      console.error('Native contact picker failed:', pickError)
      setError('تعذر اختيار جهة الاتصال.')
    }
  }

  return (
    <section className="surface-card" dir="rtl">
      <div className="section-heading">
        <div>
          <div className="eyebrow">ميزات الهاتف</div>
          <h2>جهات الاتصال</h2>
        </div>
      </div>

      {error && <div className="asalah-alert" role="alert">{error}</div>}

      <button className="asalah-button" type="button" onClick={() => void pickContact()}>
        اختيار من جهات اتصال الهاتف
      </button>

      {contactName && (
        <div className="list-row">
          <div className="list-main">
            <strong>{contactName}</strong>
            <span>{contactPhone || 'بدون رقم جوال'}</span>
          </div>
        </div>
      )}
    </section>
  )
}
