import { useEffect, useState } from 'react'
import { Capacitor } from '@capacitor/core'
import {
  LocalNotifications,
  PermissionStatus,
} from '@capacitor/local-notifications'

type NotificationStatus =
  | 'checking'
  | 'granted'
  | 'denied'
  | 'prompt'
  | 'unsupported'

export default function Notifications() {
  const [status, setStatus] = useState<NotificationStatus>('checking')

  useEffect(() => {
    if (!Capacitor.isNativePlatform()) {
      setStatus('unsupported')
      return
    }

    let mounted = true

    ;(async () => {
      try {
        const permission: PermissionStatus =
          await LocalNotifications.checkPermissions()

        if (!mounted) return

        if (permission.display === 'granted') {
          setStatus('granted')
        } else if (permission.display === 'denied') {
          setStatus('denied')
        } else {
          setStatus('prompt')
        }
      } catch (error) {
        console.error('Notification permission check failed:', error)

        if (mounted) {
          setStatus('unsupported')
        }
      }
    })()

    return () => {
      mounted = false
    }
  }, [])

  async function enable() {
    try {
      let permission = await LocalNotifications.checkPermissions()

      if (permission.display === 'prompt') {
        permission = await LocalNotifications.requestPermissions()
      }

      if (permission.display !== 'granted') {
        setStatus('denied')
        return
      }

      setStatus('granted')

      try {
        await LocalNotifications.createChannel({
          id: 'asalah-reminders',
          name: 'تذكيرات مفروشات الأصالة',
          description: 'إشعارات المتابعات ومواعيد تسليم الطلبيات',
          importance: 4,
          visibility: 1,
          sound: 'default',
          vibration: true,
        })
      } catch (error) {
        console.error('Notification channel creation failed:', error)
      }
    } catch (error) {
      console.error('Notification permission setup failed:', error)
      setStatus('denied')
    }
  }

  if (status === 'unsupported') {
    return null
  }

  return (
    <div className="notice-card">
      <div>
        <strong>إشعارات التطبيق</strong>

        <span>
          {status === 'granted'
            ? 'الإذن مفعّل'
            : status === 'denied'
              ? 'تم رفض الإذن'
              : status === 'checking'
                ? 'جارٍ التحقق…'
                : 'الإذن غير مفعّل'}
        </span>
      </div>

      {status !== 'granted' &&
        status !== 'checking' && (
          <button
            className="btn"
            onClick={enable}
          >
            تفعيل الإشعارات
          </button>
        )}
    </div>
  )
}
