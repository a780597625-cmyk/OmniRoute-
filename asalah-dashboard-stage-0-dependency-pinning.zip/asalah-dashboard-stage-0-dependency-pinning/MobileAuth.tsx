import { useEffect, useRef, useState } from 'react'
import { Capacitor } from '@capacitor/core'
import { App } from '@capacitor/app'
import { Browser } from '@capacitor/browser'
import { mobileSupabase } from './supabase'

export default function MobileAuth({ onSignedIn }: { onSignedIn: (email: string) => void }) {
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [debug, setDebug] = useState('')
  const mountedRef = useRef(true)

  async function handleUrl(url: string) {
    console.log('[OAuth] URL received:', url)
    try {
      const parsed = new URL(url)
      if (parsed.protocol !== 'com.asalah.furnishings:') return
      if (parsed.host !== 'auth' || parsed.pathname !== '/callback') return

      setBusy(true)
      setError('')
      setDebug('جارٍ معالجة الجلسة…')

      const code = parsed.searchParams.get('code')
      if (code) {
        const { data, error: exErr } = await mobileSupabase.auth.exchangeCodeForSession(code)
        if (exErr) throw exErr
        if (!data.session) throw new Error('لم يتم إنشاء جلسة بعد تبادل code')
      } else {
        const hash = parsed.hash.startsWith('#') ? parsed.hash.substring(1) : parsed.hash
        const hp = new URLSearchParams(hash)
        const access_token = hp.get('access_token')
        const refresh_token = hp.get('refresh_token')
        if (!access_token || !refresh_token) throw new Error('لم يتم العثور على التوكنات في رابط العودة')
        const { data, error: seErr } = await mobileSupabase.auth.setSession({ access_token, refresh_token })
        if (seErr) throw seErr
        if (!data.session) throw new Error('لم يتم إنشاء جلسة Supabase')
      }

      setDebug('تم إنشاء الجلسة. جارٍ جلب بيانات المستخدم…')
      await Browser.close().catch(() => undefined)

      const { data: ud, error: ue } = await mobileSupabase.auth.getUser()
      if (ue) throw ue
      if (!ud.user) throw new Error('لم يتم العثور على بيانات المستخدم')

      const email = ud.user.email || ''
      console.log('[OAuth] Login successful:', email)
      setDebug('تم تسجيل الدخول بنجاح.')
      if (mountedRef.current) onSignedIn(email)
    } catch (e) {
      console.error('[OAuth] callback error:', e)
      const message = e instanceof Error ? e.message : String(e)
      setError(`تعذر إكمال تسجيل الدخول.\n${message}`)
      setDebug('')
    } finally {
      setBusy(false)
    }
  }

  useEffect(() => {
    mountedRef.current = true
    if (!Capacitor.isNativePlatform()) return () => { mountedRef.current = false }

    let sub: { remove: () => Promise<void> } | undefined
    let cancelled = false

    App.addListener('appUrlOpen', ({ url }) => {
      console.log('[OAuth] appUrlOpen:', url)
      void handleUrl(url)
    }).then((listener) => {
      if (cancelled) listener.remove().catch(() => undefined)
      else sub = listener
    })

    App.getLaunchUrl().then((result) => {
      if (result?.url) {
        console.log('[OAuth] launch URL:', result.url)
        void handleUrl(result.url)
      }
    })

    return () => {
      cancelled = true
      mountedRef.current = false
      sub?.remove().catch(() => undefined)
    }
  }, [])

  async function google() {
    setError('')
    setDebug('')
    setBusy(true)
    try {
      const { data, error: aErr } = await mobileSupabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: 'com.asalah.furnishings://auth/callback',
          skipBrowserRedirect: true,
        },
      })
      if (aErr) throw aErr
      if (!data.url) throw new Error('OAuth URL missing')
      setDebug('جارٍ فتح المتصفح…')
      await Browser.open({ url: data.url, presentationStyle: 'popover' })
    } catch (e) {
      console.error('[OAuth] Google login error:', e)
      const message = e instanceof Error ? e.message : String(e)
      setError(`تعذر فتح تسجيل Google.\n${message}`)
      setBusy(false)
    }
  }

  return (
    <main className="mobile-login">
      <section className="login-card" aria-labelledby="login-title">
        <div className="login-brand" aria-hidden="true">أ</div>
        <h1 id="login-title">مفروشات الأصالة</h1>
        <p className="mobile-subtitle">
          لوحة ذكية لإدارة العملاء والطلبات والمتابعات — كل أعمالك في مكان واحد.
        </p>

        <div className="login-benefits" aria-label="مزايا التطبيق">
          <span>إدارة العملاء</span>
          <span>متابعة الطلبات</span>
          <span>تواصل أسرع</span>
        </div>

        <button className="mobile-google" onClick={google} disabled={busy} aria-busy={busy}>
          {busy ? 'جارٍ معالجة تسجيل الدخول…' : (
            <>
              <svg width="20" height="20" viewBox="0 0 48 48" aria-hidden="true">
                <path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.7 2.4 30.2 0 24 0 14.6 0 6.5 5.4 2.5 13.3l7.9 6.1C12.3 13.2 17.7 9.5 24 9.5z"/>
                <path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.9 7.2l7.7 6C44 38.3 46.5 32 46.5 24.5z"/>
                <path fill="#FBBC05" d="M10.4 28.6c-.5-1.5-.8-3-.8-4.6s.3-3.1.8-4.6l-7.9-6.1C.9 16.5 0 20.1 0 24s.9 7.5 2.5 10.7l7.9-6.1z"/>
                <path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.7-6c-2.1 1.4-4.8 2.3-8.2 2.3-6.3 0-11.7-3.7-13.6-9.9l-7.9 6.1C6.5 42.6 14.6 48 24 48z"/>
              </svg>
              تسجيل الدخول بحساب Google
            </>
          )}
        </button>

        {error && <div className="mobile-error" role="alert">{error}</div>}
        {debug && (
          <div className="mobile-error" role="status" style={{ background: '#eef4fb', color: '#536d8a', borderColor: '#c8d6ec', fontSize: 11 }}>
            {debug}
          </div>
        )}

        <div className="mobile-note">
          بياناتك محفوظة في Supabase ومحمية بجلسة حسابك.
        </div>
      </section>
    </main>
  )
}
