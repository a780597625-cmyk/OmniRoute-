import { useCallback, useEffect, useState } from 'react'
import { Browser } from '@capacitor/browser'
import { mobileSupabase } from './supabase'
import MobileAuth from './MobileAuth'
import Notifications from './Notifications'
import NativeFeatures from './NativeFeatures'
import Dashboard from './Dashboard'

export default function MobileApp() {
  const [sessionEmail, setSessionEmail] = useState<string | null>(null)

  const refreshUser = useCallback(async () => {
    try {
      const {
        data,
        error,
      } = await mobileSupabase.auth.getUser()

      if (error) {
        console.error('Failed to get current user:', error)
        setSessionEmail(null)
        return
      }

      setSessionEmail(data.user?.email || null)
    } catch (error) {
      console.error('Unexpected authentication error:', error)
      setSessionEmail(null)
    }
  }, [])

  useEffect(() => {
    void refreshUser()

    const {
      data: listener,
    } = mobileSupabase.auth.onAuthStateChange(
      (_event, session) => {
        setSessionEmail(session?.user?.email || null)
      },
    )

    return () => {
      listener.subscription.unsubscribe()
    }
  }, [refreshUser])

  async function signout() {
    try {
      const {
        error,
      } = await mobileSupabase.auth.signOut()

      if (error) {
        console.error('Sign out failed:', error)
        return
      }

      setSessionEmail(null)
    } catch (error) {
      console.error('Unexpected sign out error:', error)
    }
  }

  if (!sessionEmail) {
    return (
      <MobileAuth
        onSignedIn={(email) => {
          setSessionEmail(email)
        }}
      />
    )
  }

  return (
    <>
      <Notifications />
      <NativeFeatures />

      <Dashboard
        user={sessionEmail}
        supabase={mobileSupabase}
        onSignOut={signout}
        onOpenExternal={(url) => {
          void Browser.open({ url })
        }}
      />
    </>
  )
}
